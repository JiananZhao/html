---
name: turnaround-cyclical-evaluator
description: Evaluates investment ratings (BUY, HOLD, SELL, AVOID) for cyclical bottom, heavy CapEx transformation, or turnaround/distressed companies (e.g. INTC, MU, AMD cycle bottom) based on P/S Band, P/B (Replacement Cost), Normalized Mid-Cycle EPS, CapEx Inflection, and SOTP Real-Option Valuation. Use when assessing cyclical or turnaround stock opportunities.
allowed-tools: google_finance google:search drive sheets_agent
---

# Turnaround & Cyclical Evaluator (困境反转与周期模式)

## Summary
A multi-factor valuation and decision matrix tailored for cyclical bottom, heavy CapEx, or distressed turnaround companies. Replaces traditional PE/DCF with P/S Band, P/B (Replacement Cost), Normalized Mid-Cycle EPS, and Real-Option SOTP valuation.

## Applicable Company Profile
- Cyclical bottom, negative/inflated PE, heavy CapEx expansion, or strategic pivot.
- Examples: INTC, MU, AMD (cycle trough), WBD, BMY, INTA/heavy hardware/foundry pivots.

## Evaluation Framework & Multi-Factor Triggers

1. **P/S Band (市销率通道)**: P/S处于历史 10%-25% 极低分位数（如 P/S < 1.0x-1.5x），代表利空充分计入。
2. **重置成本与 P/B 支撑**: 市值接近/低于有形净资产重置成本（如 P/B < 1.0x-1.2x），下行风险极小。
3. **CapEx / Revenue % 拐点**: 资本开支高峰结束，新产能（如 18A / 新节点）即将量产转为 Revenue。
4. **Normalized EPS (中枢盈利)**: 基于行业中枢营运利润率推算复苏期 EPS。
5. **偿债线 (Solvency Check)**: 保证现金储备足以覆盖 8-12 季现金失血，无短期破产压顶。

## Decision Matrix & Thresholds

| 评级等级 | 触发逻辑 | 策略建议 |
| :--- | :--- | :--- |
| **买入 (BUY / 左侧建仓)** | P/S 或 P/B 处于历史 10% 底部 + CapEx 拐点显现 + 资产负债表无短债违约风险 | 周期左侧建仓，分批锁死折扣期权 |
| **持有 (HOLD / 观望反转)** | P/S 已经从底部修回至中枢（P/S Band 50% 分位数），等待经营杠杆显现 | 保持持有，等待利润端显现 |
| **减仓/卖出 (SELL / 周期见顶)** | P/S 触及历史 90% 高位，或行业需求进入周期过热，或重组破产威胁扩大 | 周期见顶，分批获利离场 |
| **避险 (AVOID / 价值陷阱)** | 业务持续失血且现金储备不足 4 季度，随时面临高债务违约 | 价值陷阱，暂不参与 |
