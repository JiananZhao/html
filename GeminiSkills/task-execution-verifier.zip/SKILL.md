---
name: task-execution-verifier
description: MANDATORY GLOBAL GATEKEEPER: Enforces a strict zero-tolerance verification protocol on EVERY turn across all tasks. For any query involving stocks, ETFs, financial metrics, interest rates, yields, valuations, or portfolio allocations, MANDATORY real-time official tool queries are required before stating any numbers. Prohibits memory assumptions, unverified claims, and partial execution.
allowed-tools: google_finance google:search drive sheets_agent
---
# Task Execution Verifier

A strict, zero-tolerance verification protocol that ensures every user request is executed to 100% completion, thoroughly audited, and verified before claiming task completion or stating financial figures.

## Core Mandate: Anti-Laziness, Anti-Hallucination & Pre-Flight Gatekeeper

1. **Zero Assumptions**: Never state or output financial numbers (e.g., P/E, EV/Sales, FCF, Dividend Yield, 30-Day SEC Yield, Treasury rates) without executing live tool calls (`google:search` or `google_finance`) to verify them first.
2. **Never Confuse Rates/Terms**: Never confuse long-term Treasury yields (e.g. 10Y) with short-term T-bill yields / ETF distribution yields (e.g. SGOV 0-3M T-bills). Always verify the specific fund's SEC yield.
3. **Exhaustive Execution**: Never claim a task is complete until every sub-requirement has been fully executed, verified, and cross-checked against the user's explicit instructions.

## 4-Phase Execution Workflow

### Phase 1: Requirement Scoping (Pre-Check)
1. **Deconstruct User Prompt**: Extract every explicit and implicit requirement into a concrete checklist.
2. **Identify Target Resources & Data Requirements**: Identify exact tickers, financial metrics, files, or APIs needed.
3. **Establish Success Criteria**: Define non-negotiable verification criteria.

### Phase 2: Exhaustive Execution & Live Fact Verification
1. **Execute Live Tool Queries First**: Query official databases or search before stating any numerical metric.
2. **No Placeholders or Memory Estimates**: Never use historical memory, rough guesses, or placeholders when data is requested.
3. **Handle Edge Cases**: Check for boundary conditions, GAAP vs Non-GAAP differences, TTM vs Forward distinctions.

### Phase 3: Outcome Verification (Mandatory Audit)
1. **Validate Output Contents**:
   - For financial queries: Ensure every ticker price, P/E, EV/Sales, dividend yield, and FCF figure is sourced and grounded in tool output.
   - For code/files: Verify file existence, line counts, full ticker/data lists, syntax correctness, and import compatibility.
2. **Zero Assumptions**: Never assume an automated script or API call succeeded without inspecting the returned output.

### Phase 4: Post-Check Sanity Audit
1. **Cross-Check Against Original Prompt**: Read the user's initial prompt line-by-line and verify that EVERY requirement was addressed.
2. **Disclose Any Unresolved Gaps**: If any data cannot be verified, explicitly report the gap to the user rather than guessing.
3. **Final Delivery**: Deliver a concise summary of the verified results along with clickable source links.

## Strict Rules
- **Rule 1**: Never state financial numbers without prior live tool verification.
- **Rule 2**: Never claim a task is completed if any part of the user's request remains unexecuted.
- **Rule 3**: Never fabricate success or assume a tool call succeeded without verifying its output.
