---
name: single-stock-fundamental-engine
description: 针对单一公司股票的基本面与财务质量量化分析引擎。深度解析最新 10-Q/10-K 财报，计算调整后自由现金流 (Adj. FCF)、净利润现金含量、ROIC vs WACC、毛利率趋势、净债务与利息保障倍数，以及垂直行业核心指标 (NRR, cRPO, DIO 等)。
---

# Single-Stock Fundamental & Quality Engine (单一股票基本面与财务质量量化引擎)

## Summary
本 Skill 专用于对单家上市公司的基本面与财报质量进行标准化、量化审计。从成长动能、真实造血能力（扣除 SBC 的自由现金流）、盈利现金含量、资产负债表安全度、资本分配效率（ROIC vs WACC）以及行业垂直特异指标等维度，输出结构化的基本面评分与风险排查报告。

## When to Use
- 当用户需要分析单只股票的基本面健康度、财报质量、真实现金流与造血能力时。
- 当需要核验公司的毛利率趋势、净负债杠杆、利息保障倍数或行业特定指标（如 SaaS 的 NRR/cRPO，芯片的存货周转天数）时。
- 作为量化投研总控系统的第一底层管线被调用。

---

## 1. 强制数据核验关卡 (Pre-Flight Data Gatekeeper)
1. **财报报告期确认 (Point-in-Time)**：
   - 必须通过实时查询核对公司最新已披露的财报季度（如 10-Q 或 10-K），严格使用官方 Filing Date 对应数据，杜绝未来函数。
2. **严禁臆测数据**：
   - 所有营收、营业利润、经营现金流 (OCF)、资本开支 (CapEx)、股权激励 (SBC)、总债务与现金等数据必须溯源自最新季报/年报，禁止使用估计值代替官方已披露数值。

---

## 2. 核心指标定义与量化计算体系

### 维度一：营收动能与定价权 (Growth & Pricing Power)
* **TTM 营收规模与同比增速 (Revenue YoY %)**：过去 4 个季度的累计营收及各季度 YoY 增速曲线。
* **毛利率 (Gross Margin) 趋势**：
  $$\text{Gross Margin} = \frac{\text{Revenue} - \text{Cost of Goods Sold}}{\text{Revenue}} \times 100\%$$
  - 检查连续 4~8 个季度的毛利率是处于扩张还是受压下行（定价权核心体现）。
* **华尔街一致预期达成率 (Consensus Beat/Miss Rate)**：最新季度实际营收/EPS 与华尔街一致预期的偏差幅度。

### 维度二：自由现金流与真实盈利质量 (FCF & Earnings Quality)
* **调整后真实自由现金流 (Adj. FCF)**：
  $$\text{Adj. FCF} = \text{经营现金流 (OCF)} - \text{资本开支 (CapEx)} - \text{股权激励费用 (SBC)}$$
  *(说明：在美股成长股中，SBC 虽然在 GAAP 现金流表中计入非现金加回，但其实质是对股东权益的直接稀释，量化估值中必须作为刚性人力成本全额扣除)*。
* **净利润现金含量 (Cash Conversion Ratio)**：
  $$\text{Cash Conversion} = \frac{\text{经营现金流 (OCF)}}{\text{净利润 (Net Income)}}$$
  - **健康标准**：$\ge 1.0$。若持续 $< 0.8$，提示存在应收账款激增、存货积压或激进收入确认风险。
* **资本开支强度 (CapEx / Revenue %)**：评估商业模式是否属于轻资产高回报型，抑或面临重资产折旧反噬。

### 维度三：资产负债表与偿债安全度 (Solvency & Financial Safety)
* **净债务规模 (Net Debt)**：
  $$\text{Net Debt} = (\text{短期借款} + \text{长期借款} + \text{资本化租赁负债}) - (\text{现金及等价物} + \text{短期投资/有价证券})$$
  - 若为负值，表示公司拥有净现金（Net Cash），抗周期能力极强。
* **净杠杆倍数 (Net Debt / EBITDA)**：
  - 稳健标准：$< 2.0\text{x}$；警戒线：$> 3.0\text{x}\sim 4.0\text{x}$。
* **利息保障倍数 (Interest Coverage Ratio)**：
  $$\text{Interest Coverage} = \frac{\text{息税前利润 (EBIT)}}{\text{利息支出 (Interest Expense)}}$$
  - 安全标准：$> 5.0\text{x}$；警戒线：$< 3.0\text{x}$。

### 维度四：资本分配效率与经济增加值 (Capital Allocation & EVA)
* **投入资本回报率 (ROIC)**：
  $$\text{ROIC} = \frac{\text{NOPAT (息税前税后利润)}}{\text{投入资本 (Total Debt + Total Equity - Excess Cash)}}$$
* **超额价值创造利差 (ROIC vs WACC)**：
  - $\text{ROIC} > \text{WACC}$：公司扩张正在为股东创造经济价值（Value Accretive）；
  - $\text{ROIC} < \text{WACC}$：公司规模扩张属于毁灭价值（Value Destructive）。
* **股东净回报率 (Total Shareholder Yield)**：
  $$\text{Shareholder Yield} = \text{股息率 (Dividend Yield)} + \text{净股份注销回购率 (Net Buyback Yield)}$$

### 维度五：垂直行业特异指标 (Vertical KPIs - 按行业自适应匹配)
* **SaaS / 订阅制软件**：
  * **净收入留存率 (NRR / Net Retention Rate)**：衡量老客户扩容（基准线通常需 $> 110\% \sim 120\%$）。
  * **当前剩余履约义务增速 (cRPO YoY %)**：衡量未来 12 个月确定性在手订单。
  * **SBC 占营收比例 (SBC / Revenue %)**：评估稀释程度（$>20\%$ 需警惕）。
* **半导体 / 电子硬件**：
  * **存货周转天数 (DIO / Days Inventory Outstanding)**：监测行业库存去化周期。
* **周期制造 / 工业能源**：
  * **固定资产周转率** 与 **产能利用率**。

---

## 3. 标准化输出结构

执行分析时，请严格按以下四部分输出：

### Part 1: 基本面与财务质量核心数据表 (Markdown Table)
列出最新财报季度的全部硬指标：
- 股票代码 / 公司名称 / 所属 GICS 行业
- 最新财报季度 / TTM 营收 / YoY 增速
- Gross Margin / 毛利率趋势
- TTM OCF / CapEx / SBC / Adj. FCF
- 净利润现金含量 (OCF / Net Income)
- 净债务 (Net Debt) / Net Debt to EBITDA / 利息保障倍数
- ROIC / WACC / 股东净回报率
- 行业专属 KPI (如 NRR, cRPO, DIO)

### Part 2: 基本面质量打分 (Quality Score: 0~100)
- **成长与定价权 (0-25分)**：根据营收增速与毛利率扩张打分。
- **真实现金流品质 (0-30分)**：根据 Adj. FCF 正负、净利润现金含量打分。
- **负债与抗风险 (0-25分)**：根据净现金/净杠杆及利息覆盖打分。
- **资本配置与回报 (0-20分)**：根据 ROIC-WACC 利差与回购注销打分。

### Part 3: 核心财务亮点 (Bull Points) 与 潜在红旗警示 (Red Flags)
- 明确指出 2~3 个财务亮点。
- 严格排查并列出所有潜在财报风险（如应收账款恶化、SBC 稀释过度、高债务到期压力）。
