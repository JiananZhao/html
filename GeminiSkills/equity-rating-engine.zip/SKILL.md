---
name: equity-rating-engine
description: Evaluates investment ratings (BUY, HOLD, SELL, AVOID) for stable growth and high-visibility companies (e.g. MSFT, AAPL, COST, NVDA) using a DCF and PE Band multi-factor framework. Use when analyzing stable growth companies or updating white-chip stock recommendations.
allowed-tools: google_finance google:search drive sheets_agent
---

# Equity Rating Engine (稳健白马模式)

## Summary
A multi-factor valuation and rating engine designed for stable growth, cash-generative white-chip companies. Evaluates Buy/Hold/Sell/Avoid ratings based on DCF intrinsic value, historical PE Band quantiles, cash flow quality (OCF/NI), and ROIC.

## Applicable Company Profile
- Stable growth, high earnings visibility, positive free cash flow.
- Examples: MSFT, AAPL, COST, NVDA, AMZN, GOOGL, META, PEP, CSCO.

## Decision Matrix & Thresholds

| 评级等级 | 触发逻辑 | 策略建议 |
| :--- | :--- | :--- |
| **买入 (BUY)** | 现价 $\le$ DCF基准价 $\times 1.05$（或低于安全边际价），且 OCF/NI $> 1.0$，ROIC $> 15\%$ | 分批建仓（首仓 30%，回踩安全边际价加仓） |
| **持有 (HOLD)** | 现价处于 DCF基准价 与 PE Band 75% 分位数之间，公允估值不追高 | 保持原仓位，等待回踩或估值消化 |
| **减仓/卖出 (SELL)** | 现价相比 DCF基准价溢价 $> 50\%-80\%$，触及 PE Band 90% 极高位 | 分批锁利，降低仓位 |
| **观望 (AVOID)** | OCF/NI $< 0.8$，现金流流失或高债务杠杆 | 现金流陷阱，暂不参与 |
