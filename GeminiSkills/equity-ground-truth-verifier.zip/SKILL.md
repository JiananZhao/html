---
name: equity-ground-truth-verifier
description: Enforces a strict 4-stage Ground-Truth Verification Protocol (Index Constituent Scrubbing, SEC EDGAR 10-Q/10-K Data Extraction, Dynamic DCF Recalibration, Live Market Data & Auto-Rating Binding) for stock valuation spreadsheets to eliminate stale, ungrounded, or erroneous financial data and valuation ratings.
allowed-tools: google_finance google:search drive sheets_agent
---

# Equity Ground-Truth Verifier

## Summary
A strict 4-stage verification protocol for auditing, populating, and updating stock valuation tracking spreadsheets. Replaces internal cell logic checks with external ground-truth validation against official SEC EDGAR filings, live market行情, and official index constituent notices.

## Zero-Assumption Pre-Check (强制前置宏观与基础数据检索)

Before executing any Stage or calculating any DCF intrinsic value:
1. **Real-time 10-Year Treasury Yield ($R_f$)**: Search for and confirm the **exact 10-Year US Treasury yield on the date of execution**. NEVER use hardcoded or assumed historical interest rates.
2. **Real-time Ticker Price & Diluted Share Count**: Fetch live trading price and diluted share count for the current trading session.
3. **Latest SEC Filing Date**: Confirm the latest 10-Q/10-K release date.

---

## 4-Stage Ground-Truth Verification Workflow

### Stage 1: Index Constituent Scrubbing (名册真实性清洗)
- **Goal**: Ensure the spreadsheet constituent list matches current official index holdings.
- **Action**: Check official Nasdaq-100 / S&P 500 annual/quarterly rebalance notices.

### Stage 2: SEC Filings & Financial Metrics Extraction (财报真实性清洗)
- **Goal**: Extract raw fundamental data directly from official SEC 10-Q/10-K filings.
- **Action**: Retrieve latest earnings releases, 10-Q, and 10-K reports.
- **Fields to Extract & Clean**: TTM Revenue, YoY Growth, OCF, CapEx, SBC, Net Debt, Interest Expense.

### Stage 3: Dynamic Model Recalibration (DCF 与估值模型重新建模)
- **Goal**: Prevent stale, historical DCF intrinsic values from persisting after fundamental shifts or rate changes.
- **Action**: Re-model WACC using the **real-time 10-Year Treasury yield ($R_f$)** obtained in the Zero-Assumption Pre-Check. Recompute 3-stage DCF intrinsic values ($V_{DCF}$) and Margin of Safety prices ($V_{MOS}$).

### Stage 4: Live Data & Auto-Rating Linkage (行情动态公式与评级自动化联动)
- **Goal**: Eliminate static stale stock prices and ungrounded "BUY" ratings.
- **Action**:
  - Re-bind live stock price (`=GOOGLEFINANCE(ticker, "price")`) and TTM PE (`=GOOGLEFINANCE(ticker, "pe")`).
  - Apply automated Buy-Side Rating logic based on recalculated $V_{DCF}$ and $V_{MOS}$.

## Gotchas
- **Do NOT rely on hardcoded interest rates or memory defaults**: Always fetch the latest 10-Year Treasury yield before running DCF models.
- **Format Sanitization**: Omit leading `+` signs in numeric strings (e.g. `12.5%` not `+12.5%`) to prevent `#ERROR!` in Google Sheets.
