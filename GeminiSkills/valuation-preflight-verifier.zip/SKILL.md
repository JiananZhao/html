---
name: valuation-preflight-verifier
description: MANDATORY FINANCIAL PRE-FLIGHT AUDIT: Enforces strict live data verification on ALL financial, stock, ETF, valuation, interest rate, yield, and portfolio discussions. Prohibits hardcoding, memory estimates, or unverified multiples (P/E, EV/Sales, SEC yield, FCF). Must execute live SEC/financial tool verification before outputting numbers.
allowed-tools: google_finance google:search drive sheets_agent
---
# Valuation Preflight Verifier

## Summary
A mandatory 4-phase audit protocol designed to eliminate hardcoded, stale, unverified, or default assumptions in financial valuations, stock metrics, ETF yields, and DCF models.

## Mandatory Pre-Flight Execution Protocol (零假设强制前置核验)

Before stating ANY financial metric (P/E, EV/Sales, FCF, Dividend Yield, SEC Yield, WACC, DCF), you MUST execute the following 4 phases sequentially:

### Phase 1: Real-Time Macro & Yield Anchor Lock (宏观与收益率精确对齐)
- **Live 10-Year US Treasury Yield ($R_f$)**: MUST query live yield on the exact day of execution using `google:search` or `google_finance`. NEVER use hardcoded memory defaults.
- **Short-Term Rates & ETF SEC Yields**: When discussing cash proxies (e.g. SGOV, BIL), MUST query the specific fund's 30-Day SEC Yield and trailing dividend yield. NEVER equate 10Y yield with 0-3M T-bill yields.
- **Equity Risk Premium (ERP) & Beta ($\beta$)**: Confirm Damodaran ERP and 5-year levered Beta from official financial databases.

### Phase 2: SEC EDGAR & Financial Ground-Truth Extraction (底层数据精准清洗)
- **Latest SEC Filing & Report Date**: Verify date of the latest 10-Q/10-K filing.
- **Financial Metrics Extraction**:
  - TTM Revenue & YoY Growth
  - Operating Cash Flow (OCF), CapEx, and Stock-Based Compensation (SBC)
  - Adjusted Free Cash Flow ($\text{FCF} = \text{OCF} - \text{CapEx} - \text{SBC}$)
  - Cash, Cash Equivalents, Short-Term Investments, and Total Debt
  - Diluted Share Count, P/E (TTM & Forward), EV/Sales, EV/EBITDA

### Phase 3: Triple-Scenario WACC & Valuation Sanity Check (估值与赔率抗偏分析)
- **Valuation Multiples Sanity Check**: Distinguish high-valuation narrative stocks (EV/Sales > 20x) from genuine value/odds opportunities.
- **Dynamic WACC Calculation**: Compute exact WACC using live $R_f$, $R_e$, $R_d$, $E/V$, $D/V$, and effective tax rate.
- **Multi-Scenario Modeling**: Always run Bear, Base, and Bull cases for FCF growth and WACC to avoid single-point optimistic bias.

### Phase 4: Pre-Flight Parameter Audit Card (前置参数核验清算卡)
- Before presenting any valuation conclusions or financial advice, verify every parameter against official sources, cite data sources with clickable links, and disclose whether FCF includes or excludes SBC.
