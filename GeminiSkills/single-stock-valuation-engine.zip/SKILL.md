---
name: single-stock-valuation-engine
description: 针对单一公司股票的多维内在价值折现与相对估值评估引擎。实时锚定 10 年期美债收益率 Rf 校准 WACC，执行强制双口径（含/扣SBC）三阶段 DCF 模型，实施反现价锚定机制推导公允价值与安全边际价格，并结合 PE/PB/EV Band 历史分位数、PEG 与乘数重构压力测试进行多重估值交叉验证。
---

# Single-Stock Valuation & Margin of Safety Engine (单一股票多维估值与安全边际引擎)

## Summary
本 Skill 专用于对单家上市公司的内在价值与相对估值进行严格的量化建模。通过强制拉取实时宏观参数（10 年期美债收益率 $R_f$）校准 WACC，执行动态三阶段 DCF 贴现计算，推导内在价值与安全边际价格，并结合 PE Band、EV/EBITDA、PEG 与华尔街一致预期进行多重估值交叉印证。

核心准则：严格贯彻**“反现价锚定（Anti-Price-Anchoring Invariant）”**与**“双口径自由现金流强制披露（Standard vs. Post-SBC Adj. FCF）”**，杜绝因股价短期暴涨暴跌导致的估值参数事后拟合与口径漂移。

## When to Use
- 当需要测算某只股票的内在公允价值（DCF Intrinsic Value）与安全边际买入价（Margin of Safety）时。
- 当需要评估当前股价倍数（P/E, EV/EBITDA, P/S）在历史估值通道（PE Band）中的分位数位置时。
- 当需要分析估值与业绩增长的匹配度（PEG Ratio）或华尔街一致目标价上涨空间时。

---

## 1. 强制宏观与市场参数前置核验 (Macro & Live Price Gatekeeper)

在执行任何估值公式或输出价格前，必须首先执行实时查询并公示《估值前置参数核验卡》：
1. **无风险利率 ($R_f$) 锚定**：
   - 必须通过实时工具查询**当天的 10 年期美国国债收益率（10-Year US Treasury Yield）**。严禁使用固定假设值或历史静态利率。
2. **实时股价与股本**：
   - 查询目标 Ticker 的当期实时市场价、52 周高低点、最新稀释总股本（Diluted Shares Outstanding）。
3. **股权风险溢价 (ERP) 与 Beta**：
   - 根据标的行业属性与历史波动率设定合理的 ERP（基准参考 4.5%~5.5%）与调整后 Beta（Adjusted Beta）。

---

## 2. 核心估值模型与算法体系

### 模型一：动态三阶段自由现金流折现模型 (Dynamic 3-Stage DCF)
* **加权平均资本成本 (WACC) 计算**：
  $$WACC = \frac{E}{V} \times R_e + \frac{D}{V} \times R_d \times (1 - T)$$
  其中股权成本：$R_e = R_f + \beta \times \text{ERP}$；债务成本：$R_d = \frac{\text{Interest Expense}}{\text{Total Debt}}$。

* **【强制双口径披露与反锚定铁律】**：
  1. **口径 A（标准 FCF）**：$\text{Standard FCF} = \text{OCF} - \text{CapEx}$。
  2. **口径 B（股东真实 Adj. FCF）**：$\text{Adj. FCF} = \text{OCF} - \text{CapEx} - \text{SBC}$（全额扣除员工股权激励）。
  * **反锚定铁律**：必须并列披露口径 A 与口径 B，并以**口径 B 作为审慎安全边际的核心基准**。现金流增速假设必须完全依据公司基本面、历史造血韧性与行业天花板，**严禁根据即期股价的上涨或下跌反向倒推/迎合调高或调低 FCF 增速或永续增长率**！

* **三阶段现金流贴现架构**：
  * **第一阶段（1~5 年预测期）**：基于管理层指引/分析师一致预期设定复合年均增速（CAGR）。
  * **第二阶段（6~10 年过渡收敛期）**：增速线性收敛至宏观长期名义 GDP 增速（如 3.0%~4.0%）。
  * **第三阶段（永续期）**：设定保守永续增长率 $g$（通常为 2.0%~2.5%，严禁高于长期 GDP 增速）。
  * **终值计算（Terminal Value）**：
    $$\text{TV}_{10} = \frac{\text{FCF}_{10} \times (1 + g)}{WACC - g}$$
* **内在公允价值与安全边际价格**：
  $$\text{Enterprise Value (EV)} = \sum_{t=1}^{10} \frac{\text{FCF}_t}{(1 + WACC)^t} + \frac{\text{TV}_{10}}{(1 + WACC)^{10}}$$
  $$\text{Equity Value} = \text{EV} - \text{Net Debt} = \text{EV} - (\text{Total Debt} - \text{Cash})$$
  $$\text{DCF 每股内在价值} = \frac{\text{Equity Value}}{\text{稀释后总股本}}$$
  $$\text{内在价值安全边际买入价 (Margin of Safety)} = \text{DCF 基准价} \times (1 - \text{折价率 } 20\%\sim 30\%)$$
  *(成长股通常要求 20% 折价，周期/重资产或高不确定性标的要求 30%~40% 折价。该价格为绝对估值底线，不受短期技术均线漂移影响)*。

### 模型二：历史估值通道、乘数重构与分位数检验 (Valuation Bands & Re-rating)
* **PE Band 通道构建**：
  * 计算过去 3~5 年滚动 TTM PE 的均值 $\mu$ 与标准差 $\sigma$。
  * 通道区间：超卖支撑线（$\mu - 2\sigma$）、合理低估线（$\mu - 1\sigma$）、中枢中轴线（$\mu$）、合理高估线（$\mu + 1\sigma$）、泡沫压力线（$\mu + 2\sigma$）。
  * 计算当前 Forward PE 位于历史区间的 **百分位排名（Percentile Rank: 0%~100%）**。
* **【增速降级与估值重构压力测试 (Multiple Compression Stress Test)】**：
  * 当高成长公司 ARR 或营收增速常态化下行（例如从 15%+ 放缓至 8%~12%）时，市场可能将其从“高成长 SaaS”重估为“成熟期现金牛”。
  * 必须测算当 PE 均值中枢下移至行业成熟期乘数（如 15x~20x）时的**估值底托价格**，防范估值陷阱。
* **EV / EBITDA (NTM) & EV / Sales**：
  * 剔除资本结构与杠杆差异，评估企业价值乘数与同业中位数（Peer Median）对比。
* **PEG 匹配度**：
  $$\text{PEG} = \frac{\text{Forward PE}}{\text{未来 3~5 年预期 EPS CAGR } \times 100}$$
  * $\text{PEG} < 1.0$：显著低估；$1.0 \le \text{PEG} \le 1.5$：合理区间；$\text{PEG} > 2.0$：高估。

### 模型三：市场预期与折价空间
* **52 周高点折价率 (Discount to 52W High %)**。
* **华尔街一致目标价（Consensus Target Price）与隐含上行空间 (%)**。

---

## 3. 标准化输出结构

### Part 1: 《估值前置参数核验卡》
```
============================= 估值前置参数核验卡 =============================
- 标的代码 / 现价: [Ticker] / $[Price]
- 10 年期美债无风险利率 (Rf): [x.xx]% (实时数据源)
- 股权风险溢价 (ERP) / Beta: [x.x]% / [x.xx]
- 加权平均资本成本 (WACC): [x.xx]%
- 永续增长率 (g): [x.x]%
=============================================================================
```

### Part 2: 《多维估值交叉验证表》
| 估值方法 | 测算基准价 / 乘数 | 安全边际买入价 / 合理区间 | 当前股价溢价/折价 | 历史分位数 / 评级 |
| :--- | :--- | :--- | :--- | :--- |
| **3阶段 DCF (标准 FCF)** | $[DCF Base] | $[Safety Price] (-20%) | [+/- xx]% | [低估/合理/高估] |
| **3阶段 DCF (扣SBC Adj.)** | $[DCF Base Adj] | $[Safety Price Adj] (-20%) *(核心)* | [+/- xx]% | [核心安全边际] |
| **PE Band 通道** | TTM PE: [xx]x / Fwd: [xx]x | 合理中枢: [xx]x ($\mu \pm 1\sigma$) | [当前偏离度] | 分位: [xx]% |
| **PEG 增长匹配** | PEG: [x.xx] | 基准合理线: 1.0x~1.5x | - | [高性价比/充分定价] |
| **EV/EBITDA (NTM)** | [xx]x | 同业中位数: [xx]x | [溢价/折价] | [横向估值定位] |
| **华尔街一致预期** | 目标均价: $[Target] | 预测区间: $[Low] ~ $[High] | 隐含空间: [+/- xx]% | [Consensus 倾向] |

### Part 3: 估值综合打分 (Valuation Score: 0~100) 与定级
* **打分权重**：DCF 折价空间 (40分) + PE Band 历史分位 (25分) + PEG 匹配度 (20分) + 华尔街上行空间 (15分)。
* **估值定级**：
  * **Deep Value (极度低估)**: 当前股价低于安全边际价，PE 分位 $< 15\%$
  * **Reasonable / Undervalued (合理偏低)**: 当前股价位于 DCF 与安全边际价之间
  * **Fairly Priced (充分定价)**: 处于历史估值中枢，PEG 处于 1.2~1.8
  * **Overvalued / Stretched (估值透支/泡沫)**: 突破 $\mu + 2\sigma$，PEG $> 2.5$
