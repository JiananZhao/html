---
name: single-stock-quant-orchestrator
description: 单一股票量化多因子主控与综合研报编排引擎。统筹调度基本面质量 (30%)、内在估值折现 (25%)、量价技术动量 (20%)、衍生品期权与空头筹码 (15%) 及分析师预期修正 (10%) 五大维度，执行前置参数核验，严格采用反锚定双轨制买入与风控架构，计算综合量化得分 (0~100) 并输出标准化单股买方研报与分流交易执行评级。
---

# Single-Stock Quant Orchestrator (单一股票量化多因子主控编排引擎)

## Summary
本 Skill 是单股量化与基本面融合投研的**总控枢纽（Master Orchestrator）**。负责接收用户对单家公司的分析需求，统一执行前置宏观与行情参数核验，协调调用三大专精引擎（`single-stock-fundamental-engine`、`single-stock-valuation-engine`、`single-stock-market-micro-engine`），运行 **五维加权多因子打分矩阵（满分 100 分）**，最终生成高度结构化、逻辑严密的机构级单股量化买方研报。

核心升级：严格落实**“反现价锚定（Anti-Price-Anchoring）”**与**“双轨制买入与分流风控体系（Dual-Track Entry & Bifurcated Risk Architecture）”**，彻底解决左侧价值安全边际与右侧动量止损在交易执行建议中的逻辑冲突与自适应漂移问题。

## When to Use
- 当用户要求对单只股票进行全维度量化分析、深度诊断或投资价值评估时（例如：“分析 AAPL”、“对 NVDA 做量化多因子体检”、“评估 TSLA 当前是否值得买入”）。
- 当需要一站式输出结合“基本面护城河 + DCF内在价值安全边际 + 量价动量择时 + 期权筹码微观结构”的完整投资研报时。

---

## 1. 4 阶段端到端执行工作流 (4-Phase Execution Workflow)

### Phase 1: 前置参数与宏观数据强制核验 (Pre-Flight Gatekeeper)
在进行任何打分或结论输出前，必须首先调用实时检索工具获取：
1. **宏观无风险利率锚点**：获取当天实时的 **10 年期美国国债收益率 ($R_f$)**。
2. **标的行情与股本**：目标 Ticker 的实时价格、52 周高低点、稀释总股本。
3. **最新财报报告期**：确认最新已披露的 10-Q/10-K 季度（严格使用官方披露日期数据，杜绝未来函数）。

### Phase 2: 并行调度三大专精引擎 (Engine Orchestration)
总控引擎调度三大底层专精模块获取全量因子数据：
1. **调度基本面与财务质量引擎 (`single-stock-fundamental-engine`)**：
   - 提取 TTM 营收、过去 4 季 YoY 增速、毛利率趋势；
   - 计算真实调整后自由现金流（$\text{Adj. FCF} = \text{OCF} - \text{CapEx} - \text{SBC}$）；
   - 计算净利润现金含量（$\text{OCF} / \text{Net Income}$）、净债务（Net Debt）、$\text{Net Debt} / \text{EBITDA}$、利息保障倍数；
   - 评估 $\text{ROIC vs. WACC}$ 经济增加值（EVA）与垂直行业 KPI（如 SaaS 的 NRR/cRPO，硬件制造的存货周转天数 DIO）。
2. **调度多维估值与安全边际引擎 (`single-stock-valuation-engine`)**：
   - 测算动态 WACC，运行三阶段 DCF 模型得出基准内在价值与安全边际价格（通常折价 20%~30%）；强制并列展示标准 FCF 与扣除 SBC 后的 Adj. FCF 双口径；
   - 构建过去 3~5 年滚动 PE Band（$\mu \pm 1\sigma, \pm 2\sigma$），计算当前 Forward PE 所处百分位分位数（Percentile Rank）；
   - 计算 PEG Ratio 与 EV/EBITDA (NTM)；
   - 提取华尔街一致预期目标均价与隐含上行空间。
3. **调度量价动量与微观筹码引擎 (`single-stock-market-micro-engine`)**：
   - 提取 20D/50D/200D 均线位置与偏离度（Bias %）、12-1 个月经典动量、相对 SPY 与行业 ETF 的相对强弱（Alpha）；
   - 提取日线/周线 RSI(14) 与自适应真实波动率 ATR%；
   - 提取期权隐含波动率排名（IV Rank / IV Percentile）、单股 Put/Call Ratio、期权偏斜度（Skew）；
   - 提取做空比例（Short % of Float）、空头回补天数（Days to Cover）及过去 90 天分析师 EPS 预期修正广度（Revision Breadth）。

### Phase 3: 五维量化多因子打分矩阵 (Multi-Factor Scoring Matrix: 满分 100 分)

| 因子维度 | 权重 | 核心考察指标与打分规则 |
| :--- | :--- | :--- |
| **一、质量分 (Quality Score)** | **30%** | • 营收 YoY 增速与毛利率持续扩张 (10分)<br>• Adj. FCF 为正且现金含量 $\ge 1.0$ (10分)<br>• 净杠杆 $<2.0\text{x}$ 且利息覆盖 $>5\text{x}$ (5分)<br>• $\text{ROIC} > \text{WACC}$ 持续创造股东价值 (5分) |
| **二、估值分 (Valuation Score)** | **25%** | • 股价低于或接近 DCF 安全边际买入价 (10分)<br>• PE Band 历史分位数处于低位 $<30\%$ (6分)<br>• PEG $\le 1.5$ 增长估值匹配良好 (5分)<br>• 华尔街目标价隐含上行空间 $> 20\%$ (4分) |
| **三、动量分 (Momentum Score)** | **20%** | • 均线呈多头排列且中周期 12-1M 动量走强 (10分)<br>• 相对大盘 SPY 与对应行业 ETF 具备正 Alpha (5分)<br>• RSI 处于 45~65 健康区间且无顶部背离 (5分) |
| **四、筹码与衍生品分 (Positioning)** | **15%** | • 期权 IV Rank 处于合理区间未过度透支 (5分)<br>• Put/Call Ratio 多空博弈平衡 (5分)<br>• 空头比例适度，无极端机构抛压或存在轧空催化 (5分) |
| **五、预期修正分 (Revision Score)** | **10%** | • 过去 90 天分析师 EPS/Revenue 预期上修占比 $> 65\%$ (10分)<br>*(若下调占多数则酌情扣分)* |

### Phase 4: 综合投资评级与反锚定双轨制执行决策 (Dual-Track Decision Matrix)

$$\text{综合得分 (Total Quant Score)} = \sum (\text{各维度得分} \times \text{权重})$$

* **综合评级标准**：
  * **$\ge 80$ 分**：**STRONG BUY / BUY (买入 / 积极建仓)** —— 基本面扎实、估值具备安全边际且技术面与预期共振向上。
  * **$65 \sim 79$ 分**：**ACCUMULATE / HOLD (分批建仓 / 逢低增持 / 持有)** —— 长期价值突出，但短期估值或技术面可能处于震荡等待催化阶段。
  * **$50 \sim 64$ 分**：**NEUTRAL / WATCH (观望 / 中性 / 谨慎持有)** —— 多空因子相互抵消，胜率或赔率中等。
  * **$35 \sim 49$ 分**：**TRIM / REDUCE (高位减仓 / 止盈锁定)** —— 估值显著透支（PE Band $> \mu + 2\sigma$）、动量衰竭或盈利预期下调。
  * **$< 35$ 分** 或 **触发重大财务红旗 (Red Flags)**：**AVOID / SELL (回避 / 清仓卖出)** —— 财务造血恶化、高杠杆断裂风险或估值严重泡沫。

* **【核心铁律】买入价格与风控的双轨制分流架构 (Dual-Track Execution Rules)**：
  1. **轨道 1：内在价值安全边际买入网格（Intrinsic Margin of Safety / Value Entry）**：
     - **反锚定铁律（Anti-Anchoring Rule）**：绝对价值买入点必须且只能由 $\text{DCF 内在公允价值 (扣 SBC 后)} \times (1 - \text{折价率 } 20\%\sim 30\%)$ 与历史 PE Band 极值底托硬性决定。**严禁以当前市价（Spot Price）为基数随意加减 ATR 或随股价短期涨跌发生漂移**。
     - 适用资金：左侧长线价值投资者、基本面配置账户。策略为“越跌安全边际越大、在安全边际价以下执行分批限价吸筹”，不设由于技术破位触发的割肉止损，仅在基本面出现不可逆破坏时清仓。
  2. **轨道 2：右侧战术动量突破与均线入场点（Tactical Momentum / Trend Entry）**：
     - 由均线共振（如 20D/50D/200D 突破或回踩）及日内波动率（$k \times \text{ATR}$）决定。
     - **背离警示（Divergence Warning）**：若当前市价显著高于“内在价值安全边际价”，研报中必须以醒目粗体注明：*“当前技术买点属于高溢价趋势博弈（Momentum Play），缺乏内在价值安全边际保护，必须配合严格的硬性止损纪律”*。
     - 适用资金：右侧趋势交易者、动量择时账户。
  3. **破位矛盾处置协议（Paradox Resolution Protocol）**：
     - 当股价跌穿右侧均线或 ATR 止损位，但同时处于更深度的左侧安全边际时，研报**必须明确分流指导**：
       - *对趋势交易者*：触碰止损线必须机械执行平仓离场，不可借口“基本面便宜”抗单；
       - *对价值配置者*：技术破位不触发止损，反而激活次级安全网格加仓逻辑。

---

## 2. 标准化买方研报输出模板

执行综合分析时，严格遵循以下 7 模块结构输出：

```markdown
# [公司名称] ([Ticker]) 全维度量化投研与买方诊断报告

> **数据核验基准**：分析日期 [YYYY-MM-DD] ｜ 标的现价 $[Price] ｜ 10Y美债无风险利率 $R_f$: [x.xx]% ｜ 最新财报: [Fiscal Quarter]

---

## 一、综合量化评分与买方投资评级

* **综合量化总分**：**[Score] / 100 分**
* **最终操作评级**：**[STRONG BUY / BUY / ACCUMULATE / NEUTRAL / TRIM / AVOID]**
* **五维雷达得分拆解**：
  * 质量分 (Quality, 30%): **[x] / 30**
  * 估值分 (Valuation, 25%): **[x] / 25**
  * 动量分 (Momentum, 20%): **[x] / 20**
  * 筹码衍生品分 (Positioning, 15%): **[x] / 15**
  * 预期修正分 (Revision, 10%): **[x] / 10**

---

## 二、基本面与真实造血能力诊断 (Fundamental & Quality)
| 财务指标 | 数值 / 状态 | 评价基准 | 质量解读 |
| :--- | :--- | :--- | :--- |
| TTM 营收 / YoY 增速 | $[xx]B / +[xx]% | 行业平均: [xx]% | [稳健扩张 / 放缓] |
| 毛利率 (Gross Margin) | [xx]% (YoY: [+/-]bps) | 连续趋势 | [定价权稳固 / 承压] |
| 调整后自由现金流 (Adj. FCF) | $[xx]B (扣除 SBC: $[xx]B) | 净利润现金含量: [x.xx]x | [真实造血优异 / 存在失真] |
| 净债务 (Net Debt) / 净杠杆 | $[xx]B / Net Debt to EBITDA: [x.x]x | 安全线: <2.5x | [资产负债表极度健康 / 承压] |
| ROIC vs WACC | ROIC: [xx]% vs WACC: [xx]% | 利差: +[xx]% | [创造经济价值 / 价值损耗] |
| 垂直行业专属指标 | [如 NRR: xx% / DIO: xx天] | 行业基准 | [业务运营健康度] |

---

## 三、内在价值折现与估值通道 (Valuation & Margin of Safety)
* **DCF 双口径测算**：
  * **标准 FCF 口径 (仅扣 CapEx)**: 基准公允价 **$[Standard DCF Price]** ｜ 20% 安全边际价 **$[Standard Safety Price]**
  * **严格 Adj. FCF 口径 (全额扣除 SBC)**: 基准公允价 **$[Adj DCF Price]** ｜ 20% 安全边际价 **$[Adj Safety Price]** *(核心基准)*
  * 当前股价相对 Adj. FCF 基准价溢价/折价: **[+/-xx]%**
* **相对估值通道 (PE Band)**：当前 Forward PE 为 **[xx]x**，处于过去 5 年历史区间的 **[xx]% 分位数**（合理估值中枢: $[xx]x$）。
* **PEG 匹配度**：当前 PEG 为 **[x.xx]**（合理区间 1.0~1.5）。
* **华尔街一致预期**：目标均价 **$[Consensus Price]**（隐含上行空间: **[+/-xx]%**）。

---

## 四、量价动量、期权与筹码微观结构 (Market Micro & Positioning)
* **技术动量**：20D/50D/200D 均线排列状态 [多头/纠缠/空头]，20D 偏离度 Bias 为 [+/-xx]%，12-1M 动量为 [xx]%，相对 SPY Alpha 为 [+/-xx]%。
* **超买超卖与波动**：日线 RSI(14) 为 **[xx]**，ATR% 为 **[x.x]%**（波动率状态评估）。
* **期权市场情绪**：期权 IV 为 [xx]%，IV Rank 为 **[xx]%**，Put/Call Ratio 为 **[x.xx]**，偏斜度 Skew 状态为 [避险溢价偏高/正常]。
* **筹码与做空**：做空比例 Short % of Float 为 **[x.x]%**，空头回补天数 DTC 为 **[x.x] 天**，高管近期净增减持状态为 [净增持/中性/净减持]。
* **预期修正广度**：过去 90 天分析师预期上修占比为 **[xx]%**。

---

## 五、核心多空催化剂 (Catalysts) 与关键反向风险 (Bear Risks)
* **多头催化剂 (Bull Catalysts)**：
  1. [催化剂 1]
  2. [催化剂 2]
* **反向破坏风险 (Bear Risks / Red Flags)**：
  1. [风险点 1]
  2. [风险点 2]

---

## 六、买方量化交易与双轨制仓位执行建议 (Actionable Execution Plan)
* **建议配置策略**：[左侧分批价值吸筹 / 右侧动量突破建仓 / 逢高减磅锁定利润 / 观望等待]
* **双轨价格网格 (Anti-Anchoring Dual-Track Grids)**：
  * **【轨道一：左侧内在价值安全边际网格 (Value Entry - 不受即期现价锚定)】**：
    * **保守安全建仓线 (Safety Buy Line)**: $[Adj Safety Price] (DCF 扣 SBC 后折价 20%)
    * **极端悲观底托线 (Bear Case Floor)**: $[Bear Case Price] (极端悲观假设下的公允价值)
    * **操作原则**: 只要企业核心护城河未受实质破坏，股价处于安全建仓线以下应执行限价分批加仓，无视短期均线破位。
  * **【轨道二：右侧技术动量与交易入场点 (Tactical Entry - 顺势而为)】**：
    * **战术突破/回踩买入点**: $[Price] (依托 20D/50D/200D 均线或形态支撑)
    * **动态防守止损位 (ATR-Based Stop-Loss)**: $[Price] (基于入场均线或现价 - 2.0x ATR)
    * **背离警示说明**: [若现价 > 安全建仓线，提示动量博弈无内在价值安全垫，必须坚决执行止损]
* **目标止盈区间 (Target Range)**：$[Target 1] (中期均值回归) ~ $[Target 2] (长期公允内在价值)
* **建议单标的仓位上限**：根据波动率与综合得分建议为投资组合的 **[x]% ~ [x]%**。
```
