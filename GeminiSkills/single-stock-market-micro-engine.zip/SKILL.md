---
name: single-stock-market-micro-engine
description: 针对单一公司股票的量价动量、期权衍生品情绪、筹码做空结构与分析师预期修正的量化微观引擎。量化分析均线偏离度、12-1M 动量、RSI、ATR% 波动率、期权 IV Rank、Put/Call Ratio、偏斜度 (Skew)、做空比例 (Short % of Float) 及华尔街预期修正广度。
---

# Single-Stock Market Micro & Technical Positioning Engine (单一股票量价动量与微观筹码引擎)

## Summary
本 Skill 专用于对单家上市公司的量价动量、期权衍生品隐含情绪、做空筹码结构及分析师预期修正进行高敏、多维度的量化评估。用于解决“公司基本面好但买入时机不对”的择时痛点，评估中短期交易胜率、极端情绪偏离度、空头挤压风险与筹码拥挤度。

## When to Use
- 当需要诊断某只股票的中短期量价趋势、均线偏离度（乖离率）或超买超卖极值（RSI / MACD 背离）时。
- 当需要排查期权市场隐含波动率异动（IV Rank / IV Percentile）、单股 Put/Call Ratio 或期权偏斜度（Skew）时。
- 当需要核验股票做空比例（Short % of Float）、空头回补天数（Days to Cover）、内部人增减持与分析师 EPS 预期修正广度时。

---

## 1. 强制数据核验关卡 (Live Market Data Gatekeeper)
1. **实时量价与行情数据**：
   - 必须通过实时工具拉取当期价格、成交量、20D/50D/120D/200D 均线位置及 ATR（平均真实波幅）。
2. **衍生品与筹码数据**：
   - 必须获取当期期权链隐含波动率、Put/Call 交易量与未平仓合约比率，以及最新披露的 Short Interest 数据。

---

## 2. 核心量化指标与算法体系

### 维度一：量价动量与均线形态 (Price/Volume & Momentum)
* **均线系统与偏离度（Moving Average Bias %）**：
  $$\text{Bias}_{20\text{D}} = \frac{\text{Price} - \text{SMA}_{20\text{D}}}{\text{SMA}_{20\text{D}}} \times 100\%, \quad \text{Bias}_{200\text{D}} = \frac{\text{Price} - \text{SMA}_{200\text{D}}}{\text{SMA}_{200\text{D}}} \times 100\%$$
  - 判断多头排列（20D > 50D > 200D）或均线死叉压力。
* **经典动量因子（12-1 Month Momentum）**：
  $$\text{MOM}_{12-1} = \frac{\text{Price}_{t-1\text{M}} - \text{Price}_{t-12\text{M}}}{\text{Price}_{t-12\text{M}}} \times 100\%$$
  - *(剔除近 1 个月的短期反转噪音，衡量中期趋势强度)*。
* **相对超额收益（Alpha vs. SPY / Sector ETF）**：
  - 计算过去 1M / 3M / 6M 相对大盘指数（SPY）及所属行业 ETF（如 XLK / XLF / XLE / SMH）的超额强弱比（RS Ratio）。
* **超买超卖与自适应波动**：
  * **日线 / 周线 RSI(14)**：$\text{RSI} > 75$ 提示极端超买/多头拥挤；$\text{RSI} < 30$ 提示极端超卖。
  * **自适应波动率（ATR%）**：
    $$\text{ATR}\% = \frac{\text{ATR}_{14\text{D}}}{\text{Price}} \times 100\%$$
    - 用于设定动态自适应止损位（如 $2.0 \times \text{ATR}$）与波动率平价仓位权重。

### 维度二：期权衍生品与波动率情绪 (Options & Volatility Sentiment)
* **期权隐含波动率排名（IV Rank & IV Percentile）**：
  $$\text{IV Rank} = \frac{\text{Current IV} - \text{52W Low IV}}{\text{52W High IV} - \text{52W Low IV}} \times 100\%$$
  - $\text{IV Rank} > 70\%$：期权定价极贵，常出现在财报日前或黑天鹅恐慌抛售期；
  - $\text{IV Rank} < 20\%$：期权极度便宜，隐含波动率被压制，适合低成本布局期权对冲。
* **单股 Put/Call Ratio（成交量 PCR 与持仓量 PCR）**：
  - 衡量多空投机与对冲力量对比。
* **期权偏斜度（Volatility Skew）**：
  - 虚值看跌期权（25-Delta OTM Put）IV 与 虚值看涨期权（25-Delta OTM Call）IV 的差值，衡量机构对下行崩盘保护的支付溢价。

### 维度三：筹码结构与做空压力 (Positioning & Short Interest)
* **做空比例（Short Interest as % of Float）**：
  - $< 3\%$：极低空头关注度；
  - $3\% \sim 8\%$：正常区间；
  - $> 10\% \sim 15\%$：空头高度集聚，警惕基本面重大利空或潜在逼空（Short Squeeze）机会。
* **空头回补天数（Days to Cover / Short Ratio）**：
  $$\text{Days to Cover} = \frac{\text{空头总持股数}}{\text{过去 30 日日均成交量 (ADTV)}}$$
  - 若 $> 5\sim 7$ 天，表明一旦出现利好催化剂，空头难以迅速平仓，极易引发暴力轧空。
* **高管/内部人交易（Insider Sentiment）**：
  - 跟踪过去 3~6 个月 Form 4 披露的高管纯二级市场净增持/净减持比例。

### 维度四：分析师预期修正广度 (Earnings Revision Breadth - 高敏 Alpha)
* **预期上修占比（Revision Ratio）**：
  $$\text{Revision Breadth} = \frac{\text{Up Revisions (过去 90 天上修分析师数)}}{\text{Total Revisions (上修 + 下调分析师总数)}} \times 100\%$$
  - 在量化基本面动量中，分析师连续上调盈利预期是驱动股价跑赢大盘的高胜率前瞻因子。

---

## 3. 标准化输出结构

### Part 1: 《量价动量与微观筹码数据看板》
| 监控维度 | 关键指标 | 当前数值 / 状态 | 历史定位 / 信号解读 |
| :--- | :--- | :--- | :--- |
| **技术动量** | 20D / 50D / 200D 均线 | 股价: $[P] (20D: [x] / 200D: [x]) | [多头/空头排列 / 乖离率 Bias: xx%] |
| **中周期强度**| 12-1M 动量 / 相对 RS | MOM: [xx]%, vs SPY: [+/-xx]% | [强势领涨 / 弱势跑输] |
| **震荡与波动** | 日线/周线 RSI / ATR% | RSI(14): [xx] / ATR%: [x.x]% | [超买/中性/超卖 / 动态止损参考: $[x]] |
| **期权情绪** | IV Rank / IV 分位 | IV: [xx]%, IV Rank: [xx]% | [波动率压制/适中/事件溢价过热] |
| **衍生品偏向** | Put/Call Ratio / Skew | Vol PCR: [x.xx] / Skew: [x.xx] | [偏向看多 / 偏向避险] |
| **做空与筹码** | Short % Float / DTC | Short Float: [x.x]% / DTC: [x.x]天 | [筹码结构稳定 / 逼空/拥挤风险] |
| **预期修正** | 90天 EPS 预期修正广度 | 上修 [x] 家 / 下调 [x] 家 (比率: [xx]%) | [盈利预期持续上修 / 盈利预期下调] |

### Part 2: 动量与微观筹码综合打分 (Momentum & Micro Score: 0~100)
* 均线趋势与中周期动量 (30分) + 超买超卖与 RSI 状态 (20分) + 期权 IV 与 PCR 情绪 (25分) + 空头筹码与分析师预期修正 (25分)。

### Part 3: 交易择时与筹码风险诊断
* 明确输出：**当前技术面处于顺势做多、高位震荡钝化、超卖反弹还是破位下行阶段**；
* 标明基于 ATR% 的**建议动态跟踪止损/防守参考位**。
